﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace prueba1.Models.Request
{
    public class CargaRequest
    {
        public int tamanoCamion { get; set; }
        public int carga1 { get; set; }
        public int carga2 { get; set; }
        public int carga3 { get; set; }
        public int carga4 { get; set; }
        public int carga5 { get; set; }
    }
}